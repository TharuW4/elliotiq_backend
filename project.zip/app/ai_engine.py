import json
import re
import time
from google import genai
from . import config
import pandas as pd

# --- KEY ROTATION & HYBRID LOGIC START ---
CURRENT_KEY_INDEX = 0


def get_next_free_client():
    """Returns a client using the next available FREE key from the pool."""
    global CURRENT_KEY_INDEX

    if not hasattr(config, "API_KEY_POOL") or not config.API_KEY_POOL:
        return None

    key = config.API_KEY_POOL[CURRENT_KEY_INDEX]
    CURRENT_KEY_INDEX = (CURRENT_KEY_INDEX + 1) % len(config.API_KEY_POOL)
    return genai.Client(api_key=key)


def generate_content_smart(model_name, prompt):
    """
    SMART HYBRID STRATEGY:
    1. Try all FREE keys in the pool (Round-Robin).
    2. If ALL free keys fail (Rate Limited 429), switch to PAID key.
    """
    if hasattr(config, "API_KEY_POOL") and config.API_KEY_POOL:
        attempts = 0
        max_free_retries = len(config.API_KEY_POOL)

        while attempts < max_free_retries:
            try:
                client = get_next_free_client()
                if not client:
                    break

                response = client.models.generate_content(model=model_name, contents=prompt)
                return response.text

            except Exception as e:
                error_msg = str(e)
                if "429" in error_msg or "ResourceExhausted" in error_msg or "Quota" in error_msg:
                    print(f"⚠️ Free Key {CURRENT_KEY_INDEX} Rate Limited. Switching to next...")
                    attempts += 1
                    time.sleep(0.5)
                    continue
                else:
                    print(f"❌ AI Logic Error (Non-Limit): {error_msg}")
                    return json.dumps({"error": str(e)})

    print("⚠️ All Free Keys Exhausted! Switching to PAID KEY Backup...")

    if hasattr(config, "PAID_API_KEY") and config.PAID_API_KEY:
        try:
            client = genai.Client(api_key=config.PAID_API_KEY)
            response = client.models.generate_content(model=model_name, contents=prompt)
            print("✅ Success using PAID KEY.")
            return response.text
        except Exception as e:
            print(f"❌ Paid Key Failed: {e}")
            return json.dumps({"error": f"PAID_KEY_FAILED: {str(e)}"})

    return json.dumps({"error": "ALL_SYSTEMS_BUSY (No Keys Available)"})


# --- KEY ROTATION LOGIC END ---


# --- HELPER FUNCTIONS ---

def format_waves(waves):
    """Formats wave pivot points into a readable string."""
    if not waves:
        return "No clear structure found."

    txt = ""
    for w in waves:
        try:
            d = w["p"]["date"]
            date_str = d if isinstance(d, str) else d.strftime("%Y-%m-%d %H:%M")
            txt += f"- Wave {w['lbl']} peak/low at {_format_trade_price(w['p']['price'])} on {date_str}\n"
        except Exception:
            continue
    return txt


def get_last_macro_label(waves):
    if not waves:
        return "Unknown"
    return f"{waves[-1]['lbl']}"


def ensure_datetime(d):
    """Ensures the date is a comparable datetime object."""
    if isinstance(d, str):
        return pd.to_datetime(d)
    return d


def dataframe_to_csv_string(df, limit=None):
    """
    Converts DataFrame to a CSV-like string.
    If 'limit' is provided, takes the last N rows.
    If 'limit' is None, takes the whole dataframe provided.
    """
    if df is None or df.empty:
        return "No Data Available"

    subset = df.tail(limit) if limit else df.copy()

    csv_str = "Index,Date,Open,High,Low,Close\n"
    for idx, row in subset.iterrows():
        try:
            d_str = str(idx)
            o = _format_trade_price(row["Open"])
            h = _format_trade_price(row["High"])
            l = _format_trade_price(row["Low"])
            c = _format_trade_price(row["Close"])
            csv_str += f"{d_str},{d_str},{o},{h},{l},{c}\n"
        except Exception:
            continue
    return csv_str


def _extract_float(val):
    if isinstance(val, (int, float)):
        return float(val)
    if isinstance(val, str):
        clean = re.sub(r"[^\d.]", "", val)
        if clean:
            try:
                return float(clean)
            except Exception:
                return None
    return None



def _format_trade_price(value):
    """
    Dynamic price formatting.
    Keeps enough decimals for low-price coins like APE, DOGE, PEPE.
    """
    value = _extract_float(value)
    if value is None:
        return ""

    if abs(value) >= 1000:
        return f"{value:.2f}"
    elif abs(value) >= 100:
        return f"{value:.2f}"
    elif abs(value) >= 10:
        return f"{value:.3f}"
    elif abs(value) >= 1:
        return f"{value:.4f}"
    elif abs(value) >= 0.01:
        return f"{value:.4f}"
    elif abs(value) >= 0.0001:
        return f"{value:.6f}"
    else:
        return f"{value:.8f}"


def _force_wait_scenario(summary="Setup unclear. Wait for confirmation."):
    return {
        "name": "Sniper Setup",
        "trade_type": "WAIT",
        "probability": "Low",
        "summary": summary,
        "entry_zone": "",
        "targets": [],
        "invalidation": ""
    }


def _normalize_ai_output(data):
    """
    Enforce one sniper setup only.
    If LONG/SHORT is missing required numeric fields, convert it to WAIT.
    """
    if not isinstance(data, dict):
        return {
            "macro_analysis": {
                "trend": "Unknown",
                "detailed_breakdown": "Invalid AI response.",
                "key_levels": "N/A"
            },
            "micro_analysis": {
                "wave_count_status": "Unknown",
                "wave_personality": "Unknown"
            },
            "action_advice": "Wait.",
            "trade_scenarios": [_force_wait_scenario("Invalid AI response.")]
        }

    if "macro_analysis" not in data or not isinstance(data.get("macro_analysis"), dict):
        data["macro_analysis"] = {
            "trend": "Unknown",
            "detailed_breakdown": "No macro analysis provided.",
            "key_levels": "N/A"
        }

    if "micro_analysis" not in data or not isinstance(data.get("micro_analysis"), dict):
        data["micro_analysis"] = {
            "wave_count_status": "Unknown",
            "wave_personality": "Unknown"
        }

    if "action_advice" not in data or not data.get("action_advice"):
        data["action_advice"] = "Wait."

    scenarios = data.get("trade_scenarios", [])
    if not isinstance(scenarios, list) or not scenarios:
        data["trade_scenarios"] = [_force_wait_scenario("No valid setup returned.")]
        return data

    s = scenarios[0] if isinstance(scenarios[0], dict) else {}
    s.setdefault("name", "Sniper Setup")
    s.setdefault("probability", "Low")
    s.setdefault("summary", "Setup unclear. Wait for confirmation.")
    s.setdefault("entry_zone", "")
    s.setdefault("targets", [])
    s.setdefault("invalidation", "")

    trade_type = str(s.get("trade_type", "WAIT")).upper().strip()
    if trade_type not in ["LONG", "SHORT", "WAIT"]:
        trade_type = "WAIT"

    if trade_type in ["LONG", "SHORT"]:
        entry = _extract_float(s.get("entry_zone"))
        stop = _extract_float(s.get("invalidation"))
        raw_targets = s.get("targets", [])
        parsed_targets = [_extract_float(t) for t in raw_targets if _extract_float(t) is not None]

        if entry is None or stop is None or not parsed_targets:
            s = _force_wait_scenario("Incomplete setup data. Wait for confirmation.")
            data["action_advice"] = "Wait for clear setup."
        else:
            s["trade_type"] = trade_type
            s["entry_zone"] = _format_trade_price(entry)
            s["invalidation"] = _format_trade_price(stop)
            s["targets"] = [_format_trade_price(t) for t in parsed_targets[:2]]
            if not s["targets"]:
                s = _force_wait_scenario("Targets missing. Wait for confirmation.")
    else:
        s = _force_wait_scenario(s.get("summary", "Setup unclear. Wait for confirmation."))
        data["action_advice"] = "Wait for clear setup."

    if str(s.get("trade_type", "")).upper() == "WAIT":
        advice = str(data.get("action_advice", "")).lower()

        blocked_words = ["pullback to", "bounce to", "entry", "buy", "sell", "long", "short"]

        if any(word in advice for word in blocked_words):
            data["action_advice"] = "Wait for clear setup."

        s["entry_zone"] = ""
        s["targets"] = []
        s["invalidation"] = ""

    data["trade_scenarios"] = [s]
    return data


def enforce_risk_reward(ai_data, ratio=5.0):
    """
    LIGHT SANITY CHECK ONLY:
    - DO NOT heavily overwrite AI targets.
    - AI should decide:
        TP1 = exact 1.5R
        TP2 = structure-based final target
    - Backend only:
        1. validates target direction/order
        2. creates missing TP2 when only one target exists
        3. caps absurd TP2 beyond max ratio
    """
    try:
        if "trade_scenarios" not in ai_data:
            return ai_data

        scenarios = ai_data["trade_scenarios"]
        if not scenarios:
            return ai_data

        main_setup = scenarios[0]
        trade_type = str(main_setup.get("trade_type", "")).upper()

        if trade_type == "WAIT":
            return ai_data

        entry = _extract_float(main_setup.get("entry_zone"))
        stop = _extract_float(main_setup.get("invalidation"))

        if entry is None or stop is None or entry == stop:
            ai_data["trade_scenarios"] = [_force_wait_scenario("Invalid entry or stop. Wait for confirmation.")]
            return ai_data

        risk = abs(entry - stop)

        if "LONG" in trade_type:
            tp1_expected = entry + (risk * 1.5)
            tp2_cap = entry + (risk * ratio)
        elif "SHORT" in trade_type:
            tp1_expected = entry - (risk * 1.5)
            tp2_cap = entry - (risk * ratio)
        else:
            ai_data["trade_scenarios"] = [_force_wait_scenario("Invalid trade type. Wait for confirmation.")]
            return ai_data

        raw_targets = main_setup.get("targets", [])
        parsed_targets = [_extract_float(t) for t in raw_targets if _extract_float(t) is not None]

        if not parsed_targets:
            ai_data["trade_scenarios"] = [_force_wait_scenario("Targets missing. Wait for confirmation.")]
            return ai_data

        if len(parsed_targets) >= 2:
            tp1 = parsed_targets[0]
            tp2 = parsed_targets[1]
        else:
            # If AI returns only one target, treat it as TP2 and create TP1 from 1.5R
            tp1 = tp1_expected
            tp2 = parsed_targets[0]

        if "LONG" in trade_type:
            # TP1 must be above entry
            tp1 = tp1_expected

            # If AI accidentally made TP2 too close / below TP1, push it farther
            if tp2 <= tp1:
                tp2 = max(tp1 + (risk * 0.5), tp2)

            # Final cap
            if tp2 > tp2_cap:
                tp2 = tp2_cap

        else:  # SHORT
            # TP1 must be below entry
            if tp1 >= entry:
                tp1 = tp1_expected

            # If AI accidentally made TP2 too close / above TP1, push it farther down
            if tp2 >= tp1:
                tp2 = min(tp1 - (risk * 0.5), tp2)

            # Final cap
            if tp2 < tp2_cap:
                tp2 = tp2_cap

        main_setup["targets"] = [_format_trade_price(tp1), _format_trade_price(tp2)]
        main_setup["entry_zone"] = _format_trade_price(entry)
        main_setup["invalidation"] = _format_trade_price(stop)

    except Exception as e:
        print(f"RR Adjustment Logic Failed: {e}")

    return ai_data


# --- STATUS UPDATE (SIMPLIFIED FOR BEGINNERS) ---
def generate_status_update(scenario, df_recent):
    has_pool = hasattr(config, "API_KEY_POOL") and config.API_KEY_POOL
    has_paid = hasattr(config, "PAID_API_KEY") and config.PAID_API_KEY

    if not has_pool and not has_paid:
        return "AI Unreachable"

    try:
        current_price = df_recent.iloc[-1]["Close"]
        price_action = ""
        for _, row in df_recent.tail(15).iterrows():
            price_action += f"C:{_format_trade_price(row['Close'])} "

        prompt = f"""
        You are a Trading Mentor active on a live trade.
        SCENARIO: {scenario['trade_type']} on {scenario.get('name', 'Setup')}
        ENTRY: {scenario.get('entry_zone', scenario.get('entry', '0'))}
        TARGETS: {scenario.get('targets', [scenario.get('target', '0')])}
        STOP: {scenario.get('invalidation', scenario.get('stop_loss', '0'))}
        CURRENT PRICE: {current_price}
        RECENT CANDLES: {price_action}

        TASK:
        Provide an extremely SHORT, SIMPLE status update for a beginner.
        Max 15 words.
        Example:
        "Price is moving well, hold for target."
        "Momentum slowing, secure profits."
        "Limit order still pending."
        """

        response_text = generate_content_smart(config.MODEL_FAST, prompt)

        if '{"error"' in response_text:
            return "Market data analyzed. Monitor key levels."

        return response_text.strip()
    except Exception:
        return "Market data analyzed. Monitor key levels."


# --- MAIN ANALYSIS FUNCTION ---
def generate_mtf_analysis(
    symbol,
    macro_waves,
    swing_waves,
    micro_waves,
    df_micro,
    df_macro,
    user_tf,
    user_plan="Free",
    locked_scenario=None,
    market_bias="Analyze neutrally",
    market_type="crypto",
    cross_tf_context="",
    market_context_text=""
):
    has_pool = hasattr(config, "API_KEY_POOL") and config.API_KEY_POOL
    has_paid = hasattr(config, "PAID_API_KEY") and config.PAID_API_KEY

    if not has_pool and not has_paid:
        return json.dumps({"error": "No API Keys Configured"})

    if user_plan == "Free":
        return json.dumps({
            "macro_analysis": {"trend": "LOCKED", "detailed_breakdown": "Upgrade to Pro", "key_levels": "---"},
            "micro_analysis": {"wave_count_status": "Locked", "wave_personality": "Locked"},
            "trade_scenarios": []
        })

    selected_model = config.MODEL_FAST if locked_scenario else config.MODEL_SMART

    try:
        current_price = df_micro.iloc[-1]["Close"]
        last_macro_label = get_last_macro_label(macro_waves)

        # --- 1. PREPARE MACRO CONTEXT ---
        macro_csv_data = "No Macro Data"
        if macro_waves and df_macro is not None and not df_macro.empty:
            try:
                last_wave_date = ensure_datetime(macro_waves[-1]["p"]["date"])
                macro_subset = df_macro[df_macro.index >= last_wave_date]
                if len(macro_subset) < 30:
                    macro_subset = df_macro.tail(30)
                macro_csv_data = dataframe_to_csv_string(macro_subset, limit=None)
            except Exception as e:
                print(f"Macro Data Error: {e}")
                macro_csv_data = dataframe_to_csv_string(df_macro, limit=100)

        # --- 2. PREPARE MICRO CONTEXT ---
        micro_csv_data = dataframe_to_csv_string(df_micro, limit=500)

        # --- 3. FORMAT WAVE STRUCTURES ---
        macro_structure_text = format_waves(macro_waves)
        micro_structure_text = format_waves(micro_waves)
        swing_structure_text = format_waves(swing_waves)

        market_context_note = ""
        if market_type == "forex":
            market_context_note = """
            *** FOREX MARKET ALERT ***
            - This is a Fiat Pair or Commodity (Gold/Oil).
            - Market closes on Weekends (expect gaps).
            - High sensitivity to London/New York session overlaps.
            - Volatility is measured in Pips.
            - Consider USD Index (DXY) correlation implicitly.
            """

        base_context = f"""
        CONTEXT:
        Symbol: {symbol}
        Market Type: {market_type.upper()}
        {market_context_note}

        --- ALGORITHMIC WAVE ANALYSIS (GUIDE) ---
        [MACRO WAVES DETECTED - Daily]:
        {macro_structure_text}

        [SWING WAVES DETECTED - 4H]:
        {swing_structure_text}

        [MICRO WAVES DETECTED - {user_tf}]:
        {micro_structure_text}

        Last Macro Label detected: **{last_macro_label}**.

        --- DATA LAYER A: MACRO STRUCTURE (Daily 1D) ---
        MACRO CSV (Daily):
        {macro_csv_data}

        --- DATA LAYER B: MICRO STRUCTURE ({user_tf}) ---
        MICRO CSV ({user_tf}):
        {micro_csv_data}

        --- EXISTING SETUPS ON OTHER TIMEFRAMES ---
        The following are ACTIVE Locked trades on different timeframes for this coin.
        Use them for CONFLUENCE. Do NOT contradict them unless there is a strong reversal signal.
        DATA: {cross_tf_context if cross_tf_context else "None"}

        --- MARKET STRUCTURE / FIB / ATR / VOLUME CONTEXT ---
        {market_context_text if market_context_text else "No additional market context available."}

        CURRENT PRICE: {current_price}
        """

        if locked_scenario:
            prompt = f"""
            Act as an expert Elliott Wave analyst and live trade manager.

            {base_context}

            LOCKED SCENARIO (ACTIVE TRADE): {json.dumps(locked_scenario)}

            TASK:
            1. Validate whether the LOCKED SCENARIO is still valid using macro structure, micro structure, market context, and recent price action.
            2. Respect and monitor the locked scenario unless it is clearly invalidated.
            3. Do NOT generate a new trade while the locked scenario is active.
            4. Only update the status/advice for the locked scenario.
            5. Provide a VERY SHORT beginner-friendly action advice.

            STRICT RULES:
            1. Return ONLY ONE scenario in trade_scenarios.
            2. The returned scenario must represent the LOCKED SCENARIO only, not a new trade.
            3. Use OLD SCHEMA ONLY: entry_zone, targets, invalidation.
            4. Keep the original locked entry_zone, targets, and invalidation unless the scenario is clearly invalidated.
            5. If the locked scenario is still valid, action_advice must say one of:
                - "Limit order still pending."
                - "Hold position."
                - "Secure profits."
                - "Monitor closely."
            6. If active entry has not been reached yet, action_advice must say "Limit order still pending."
            7. If price moved away from entry before fill, action_advice must say "No chase. Entry missed."
            8. If current price is closer to TP1 than entry before fill, action_advice must be "No chase. Entry missed."
            9. If locked scenario is invalidated, clearly say invalidated in summary.
            10. Keep action_advice extremely short and beginner friendly.
            11. Summary must be concise and professional.

            OUTPUT JSON ONLY:
            {{
                "macro_analysis": {{
                    "trend": "Bullish/Bearish/Sideways",
                    "detailed_breakdown": "Short macro update on the larger structure.",
                    "key_levels": "Important support and resistance levels."
                }},
                "micro_analysis": {{
                    "wave_count_status": "Short update on immediate wave condition.",
                    "wave_personality": "Impulsive/Corrective/Unclear"
                }},
                "action_advice": "VERY SHORT beginner-friendly advice.",
                "trade_scenarios": [
                    {{
                        "name": "Sniper Setup",
                        "trade_type": "LONG/SHORT/WAIT",
                        "probability": "High/Medium/Low",
                        "summary": "Locked scenario status update only. No new trade generated.",
                        "entry_zone": "SPECIFIC_SINGLE_PRICE",
                        "targets": ["FIRST_TARGET_PRICE", "SECOND_TARGET_PRICE"],
                        "invalidation": "STOP_LOSS_PRICE"
                    }}
                ]
            }}
            """
        else:
            prompt = f"""
            Act as an expert Elliott Wave analyst and professional crypto signal strategist.

            {base_context}

            TASK:
            Analyze the market using:
            1. Elliott Wave structure
            2. Macro trend vs micro setup alignment
            3. Support and resistance behavior
            4. Fibonacci / ATR / volume context as supporting evidence
            5. Continuation vs correction logic
            6. Entry quality (do not force trades)

            ---> GLOBAL INSTRUCTION: {market_bias} <---
            Prioritize this direction ONLY if the technical structure supports it.

            STRICT RULES:
            1. Return ONLY ONE final setup in trade_scenarios.
            2. Use OLD SCHEMA ONLY: entry_zone, targets, invalidation.
            3. trade_type must be LONG, SHORT, or WAIT.
            4. If setup is weak, unclear, already missed, or incomplete, return WAIT.
            5. Do NOT return LONG or SHORT without entry_zone, exactly TWO targets, and invalidation.
            6. entry_zone must be ONE exact price only. No ranges.
            7. invalidation must be ONE exact price only.
            8. targets must contain TWO prices:
                - target 1 = exact 1.5R based on entry_zone and invalidation
                - target 2 = structure-based final target selected by AI
            9. Never use the structure target as target 1. Only target 1 is formula-based.
            10. Target 2 should reflect real chart structure: local high/low retest, wave completion zone, Fibonacci extension, or major support/resistance.
            11. Elliott Wave structure is the PRIMARY model. Market Structure / Fib / ATR / Volume Context is supporting evidence only.
            12. Do not create a trade only because market context shows support/resistance or Fibonacci levels.
            13. Use market context only to confirm, reject, or refine Elliott-based setups.
            14. Re-check whether the correction is complete or still ongoing before giving direction.
            15. If macro trend strongly conflicts with the setup, lower confidence or return WAIT.
            16. Entry must be realistic relative to CURRENT PRICE.
            17. If LONG entry_zone is below CURRENT PRICE, treat it as a limit pullback entry and action_advice must include the exact entry price, e.g. "Wait for pullback to 77750."
            18. If SHORT entry_zone is above CURRENT PRICE, treat it as a limit bounce entry and action_advice must include the exact entry price, e.g. "Wait for bounce to 78500."
            19. If CURRENT PRICE is closer to target 1 than to entry_zone, or price has already moved more than 50% from entry_zone toward target 1, return WAIT with action_advice = "No chase. Wait for new setup."
            20. For 15m crypto sniper setups, use a tight but realistic stop:
                - stop loss should usually be within 1.2x to 2.0x ATR from entry
                - avoid stops beyond 2.5x ATR unless the setup is exceptionally clean
                - stop loss must be beyond nearest valid structural invalidation with a small ATR buffer, not far macro invalidation
                - if required stop is too wide, return WAIT
            21. If a LONG setup targets directly into nearby major resistance and higher timeframe bias is bearish, prefer WAIT or a SHORT bounce setup.
            22. If 1h/4h bias strongly conflicts with the 15m setup, do not take a countertrend setup unless reversal confirmation is clear.
            23. Keep action_advice short and beginner friendly. Summary must clearly explain entry, SL, TP1, and TP2 logic.

            OUTPUT JSON ONLY:
            {{
                "macro_analysis": {{
                    "trend": "Bullish/Bearish/Sideways",
                    "detailed_breakdown": "Explain the larger structure seen in macro data and detected waves.",
                    "key_levels": "Key support and resistance levels from macro structure."
                }},
                "micro_analysis": {{
                    "wave_count_status": "Current sub-wave count based on micro structure.",
                    "wave_personality": "Impulsive/Corrective/Unclear"
                }},
                "action_advice": "Simple, short, beginner-friendly advice.",
                "trade_scenarios": [
                    {{
                        "name": "Sniper Setup",
                        "trade_type": "LONG/SHORT/WAIT",
                        "probability": "High/Medium/Low",
                        "summary": "High-quality sniper setup aligned with macro and micro structure. TP1 is the safer 1.5R exit, while TP2 is the structure-based final target.",
                        "entry_zone": "SPECIFIC_SINGLE_PRICE",
                        "targets": ["FIRST_TARGET_PRICE", "SECOND_TARGET_PRICE"],
                        "invalidation": "STOP_LOSS_PRICE"
                    }}
                ]
            }}
            """

        try:
            with open("debug_ai_prompt.txt", "w", encoding="utf-8") as f:
                f.write(prompt)
            print("✅ AI prompt saved to debug_ai_prompt.txt")
        except Exception as e:
            print(f"Prompt debug save failed: {e}")

        raw_text = generate_content_smart(selected_model, prompt)


        if '{"error"' in raw_text:
            return raw_text

        cleaned_text = raw_text.replace("```json", "").replace("```", "").strip()
        match = re.search(r"\{.*\}", cleaned_text, re.DOTALL)

        if match:
            json_str = match.group(0)
            try:
                data = json.loads(json_str)
                data = _normalize_ai_output(data)

                if not locked_scenario:
                    data = enforce_risk_reward(data, ratio=5.0)

                data = _normalize_ai_output(data)
                return json.dumps(data)
            except Exception as e:
                print(f"JSON Parsing/Adjustment Error: {e}")
                return json.dumps({
                    "macro_analysis": {
                        "trend": "Unknown",
                        "detailed_breakdown": "AI parsing failed.",
                        "key_levels": "N/A"
                    },
                    "micro_analysis": {
                        "wave_count_status": "Unknown",
                        "wave_personality": "Unknown"
                    },
                    "action_advice": "Wait.",
                    "trade_scenarios": [_force_wait_scenario("AI parsing failed.")]
                })
        else:
            return json.dumps({"error": "No JSON found in AI response"})

    except Exception as e:
        return json.dumps({"error": str(e)})


# --- SCANNER ---
def analyze_scanner_candidates(candidates):
    has_pool = hasattr(config, "API_KEY_POOL") and config.API_KEY_POOL
    has_paid = hasattr(config, "PAID_API_KEY") and config.PAID_API_KEY

    if not has_pool and not has_paid:
        return json.dumps({"error": "No API Keys Configured"})

    candidates_str = ""
    for c in candidates:
        candidates_str += f"- {c['symbol']}: Price {c['price']}, RSI {c['rsi']:.1f}, Signal {c['signal']}\n"

    prompt = f"""
    Analyze these candidates. Pick Top 5.
    DATA:
    {candidates_str}
    OUTPUT JSON Array: [{{ "ticker": "SYM", "price": 0, "rsi": 0, "signal": "LONG/SHORT", "reason": "..." }}]
    """

    try:
        raw_text = generate_content_smart(config.MODEL_FAST, prompt)

        if '{"error"' in raw_text:
            return json.dumps([])

        cleaned = raw_text.replace("```json", "").replace("```", "").strip()
        match = re.search(r"\[.*\]", cleaned, re.DOTALL)
        return match.group(0) if match else json.dumps([])
    except Exception as e:
        return json.dumps({"error": str(e)})