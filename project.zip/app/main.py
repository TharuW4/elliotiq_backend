import sys
import json
import os
import re
import pandas as pd
import numpy as np
from datetime import datetime, timezone

# --- IMPORT CONFIG ---
from . import config

# Firebase Admin Imports
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Models imports
from .data_loader import get_data
from .models.WaveAnalyzer import WaveAnalyzer
from .models.WaveOptions import WaveOptionsGenerator5
from .models.WaveRules import Impulse, Correction
from .models.WavePattern import WavePattern
from .ai_engine import generate_mtf_analysis, analyze_scanner_candidates, generate_status_update
from .scanner import scan_market
from .models.market_context import build_market_context_text

# --- FIREBASE SETUP ---
FIREBASE_CREDENTIALS_PATH = os.getenv("FIREBASE_CREDENTIALS_PATH", "serviceAccountKey.json")

try:
    if not firebase_admin._apps:
        cred = credentials.Certificate(FIREBASE_CREDENTIALS_PATH)
        firebase_admin.initialize_app(cred)
    db = firestore.client()
    FIREBASE_AVAILABLE = True
except Exception as e:
    FIREBASE_AVAILABLE = False
    print(f"[WARN] Firebase setup failed: {e}")

COLLECTION_NAME = "global_analysis_locks"

# --- HELPER FUNCTIONS ---

def normalize_symbol(symbol: str) -> str:
    """
    Normalize symbols for consistent API/database usage.
    Examples:
      BTC/USDT -> BTCUSDT
      btcusdt  -> BTCUSDT
      BTC:USDT -> BTCUSDT
    """
    return str(symbol).replace("/", "").replace(":", "").replace(" ", "").upper()


def load_api_key():
    if not FIREBASE_AVAILABLE:
        print("[ERROR] Firebase not connected.")
        return False
    try:
        doc_ref = db.collection("app_secrets").document("config")
        doc = doc_ref.get()
        if doc.exists:
            data = doc.to_dict()
            pool = data.get("gemini_api_key_pool")
            if pool and isinstance(pool, list):
                config.API_KEY_POOL = pool
            else:
                config.API_KEY_POOL = []

            paid_key = data.get("gemini_paid_key")
            if paid_key:
                config.PAID_API_KEY = paid_key
            else:
                config.PAID_API_KEY = None

            if config.API_KEY_POOL or config.PAID_API_KEY:
                return True
        else:
            print("[ERROR] Secret config not found.")
    except Exception as e:
        print(f"[ERROR] Failed to load API Keys: {e}")
    return False


def get_firestore_lock(symbol, tf):
    if not FIREBASE_AVAILABLE:
        return None, None
    try:
        clean_symbol = normalize_symbol(symbol)
        doc_id = f"{clean_symbol}_{tf}"
        doc_ref = db.collection(COLLECTION_NAME).document(doc_id)
        doc = doc_ref.get()
        if doc.exists:
            data = doc.to_dict()
            return data.get("scenario"), data.get("updated_at")
    except Exception as e:
        print(f"[WARN] Failed to get Firebase lock: {e}")
    return None, None


def get_cross_timeframe_context(symbol, current_tf):
    if not FIREBASE_AVAILABLE:
        return ""
    try:
        clean_symbol = normalize_symbol(symbol)
        docs = db.collection(COLLECTION_NAME).where("symbol", "==", clean_symbol).stream()
        summary_list = []
        for doc in docs:
            data = doc.to_dict()
            tf = data.get("timeframe")
            if tf == current_tf:
                continue
            scenario = data.get("scenario", {})
            t_type = scenario.get("trade_type", "Unknown")
            if t_type in ["WAIT", "NEUTRAL", "Unknown"]:
                continue
            entry = scenario.get("entry_zone") or scenario.get("entry", "N/A")
            targets = scenario.get("targets", [])
            tp = targets[0] if targets else scenario.get("target", "N/A")
            summary = f"{tf}:{t_type}(E:{entry},TP:{tp})"
            summary_list.append(summary)
        return " | ".join(summary_list) if summary_list else ""
    except Exception as e:
        print(f"[WARN] Error fetching cross-tf context: {e}")
        return ""


def save_firestore_lock(symbol, tf, scenario):
    if not FIREBASE_AVAILABLE:
        return
    try:
        clean_symbol = normalize_symbol(symbol)
        doc_id = f"{clean_symbol}_{tf}"
        doc_ref = db.collection(COLLECTION_NAME).document(doc_id)
        doc_ref.set({
            "scenario": scenario,
            "updated_at": firestore.SERVER_TIMESTAMP,
            "symbol": clean_symbol,
            "timeframe": tf
        })
    except Exception as e:
        print(f"[ERROR] Failed to save Firebase lock: {e}")


def delete_firestore_lock(symbol, tf):
    if not FIREBASE_AVAILABLE:
        return
    try:
        clean_symbol = normalize_symbol(symbol)
        doc_id = f"{clean_symbol}_{tf}"
        db.collection(COLLECTION_NAME).document(doc_id).delete()
    except Exception as e:
        print(f"Error deleting lock: {e}")


def get_market_bias():
    if not FIREBASE_AVAILABLE:
        return "Analyze the market neutrally."
    try:
        doc_ref = db.collection("app_config").document("trading_bias")
        doc = doc_ref.get()
        if doc.exists:
            data = doc.to_dict()
            return data.get("instruction", "Analyze the market neutrally.")
    except Exception:
        pass
    return "Analyze the market neutrally."


def extract_price(price_str):
    try:
        if isinstance(price_str, (int, float)):
            return float(price_str)
        match = re.search(r"[\d,]+(\.\d+)?", str(price_str))
        if match:
            return float(match.group(0).replace(',', ''))
    except Exception:
        return None
    return None


def enforce_max_rr(scenario, max_r=5.0):
    try:
        t_type = scenario.get("trade_type", "").upper()
        if "LONG" not in t_type and "SHORT" not in t_type:
            return scenario

        entry = extract_price(scenario.get("entry_zone") or scenario.get("entry"))
        sl = extract_price(scenario.get("invalidation") or scenario.get("stop_loss"))
        if entry is None or sl is None:
            return scenario

        risk = abs(entry - sl)
        if risk == 0:
            return scenario

        limit_price = entry + (risk * max_r) if "LONG" in t_type else entry - (risk * max_r)

        raw_targets = scenario.get("targets", [])
        if not raw_targets and "target" in scenario:
            raw_targets = [scenario.get("target")]

        new_targets = []
        for t in raw_targets:
            val = extract_price(t)
            if val is None:
                new_targets.append(t)
                continue

            capped_val = val
            if "LONG" in t_type:
                if val > limit_price:
                    capped_val = limit_price
            else:
                if val < limit_price:
                    capped_val = limit_price

            new_targets.append(
                str(int(capped_val)) if capped_val == int(capped_val) else f"{capped_val:.2f}"
            )

        scenario["targets"] = new_targets
        if new_targets:
            scenario["target"] = new_targets[-1]
        return scenario
    except Exception:
        return scenario


def check_trade_status_historical(scenario, historical_df):
    try:
        trade_type = scenario.get("trade_type", "").upper()
        targets = scenario.get("targets", [])
        if not targets and "target" in scenario:
            targets = [scenario.get("target")]

        raw_tps = [extract_price(t) for t in targets if extract_price(t) is not None]
        tp_levels = sorted(raw_tps) if "LONG" in trade_type else sorted(raw_tps, reverse=True)

        entry_price = extract_price(scenario.get("entry_zone", "0") or scenario.get("entry", "0"))
        stop_loss = extract_price(scenario.get("invalidation", "0") or scenario.get("stop_loss", "0"))

        if not tp_levels or stop_loss is None or entry_price is None:
            return "UNKNOWN", "Data Missing"

        is_active = False
        highest_tp_hit_idx = -1
        required_win_index = 1 if len(tp_levels) > 1 else 0

        for row in historical_df.itertuples():
            curr_low, curr_high = row.Low, row.High

            if not is_active:
                if ("LONG" in trade_type and curr_low <= entry_price) or ("SHORT" in trade_type and curr_high >= entry_price):
                    is_active = True

            if is_active:
                if "LONG" in trade_type:
                    if curr_low <= stop_loss:
                        return "LOST", "Stop Loss Hit"
                    for i, tp in enumerate(tp_levels):
                        if curr_high >= tp and i > highest_tp_hit_idx:
                            highest_tp_hit_idx = i

                elif "SHORT" in trade_type:
                    if curr_high >= stop_loss:
                        return "LOST", "Stop Loss Hit"
                    for i, tp in enumerate(tp_levels):
                        if curr_low <= tp and i > highest_tp_hit_idx:
                            highest_tp_hit_idx = i

                if highest_tp_hit_idx >= required_win_index:
                    return "WON", f"Target {highest_tp_hit_idx + 1} Hit!"

        if is_active:
            if highest_tp_hit_idx == 0 and len(tp_levels) > 1:
                return "TP 1 HIT", "TP 1 Hit. Moving to TP 2..."
            last_price = historical_df.iloc[-1]["Close"]
            pnl = "Profit" if ("LONG" in trade_type and last_price > entry_price) or ("SHORT" in trade_type and last_price < entry_price) else "Drawdown"
            return f"RUNNING ({pnl})", "Trade is Active."
        else:
            return "LIMIT ORDER", "Waiting for Entry..."

    except Exception as e:
        return "UNKNOWN", str(e)


# --- ANALYSIS HELPERS ---
class WaveOptionsGenerator3:
    def __init__(self, up_to=1):
        self.options_sorted = []
        for i in range(up_to + 1):
            for j in range(up_to + 1):
                for k in range(up_to + 1):
                    self.options_sorted.append(type('obj', (object,), {'values': [i, j, k]})())
        self.options_sorted.sort(key=lambda x: sum(x.values))


def find_best_fit(wa, start_idx, end_idx_limit, generators, rules):
    best_waves, best_type, max_len = None, "", 0

    try:
        for opt in generators["impulse"].options_sorted:
            try:
                waves = wa.find_impulsive_wave(idx_start=start_idx, wave_config=opt.values)
                if waves and waves[-1].idx_end <= end_idx_limit + 10:
                    wp = WavePattern(waves, verbose=False)
                    if wp.check_rule(rules["impulse"]):
                        dur = waves[-1].idx_end - waves[0].idx_start
                        if dur > max_len:
                            max_len, best_waves, best_type = dur, waves, "Impulse"
            except Exception:
                continue
    except Exception:
        pass

    try:
        for opt in generators["correction"].options_sorted:
            try:
                waves = wa.find_corrective_wave(idx_start=start_idx, wave_config=opt.values)
                if waves and waves[-1].idx_end <= end_idx_limit + 10:
                    wp = WavePattern(waves, verbose=False)
                    if wp.check_rule(rules["correction"]):
                        dur = waves[-1].idx_end - waves[0].idx_start
                        if dur > max_len:
                            max_len, best_waves, best_type = dur, waves, "Correction"
            except Exception:
                continue
    except Exception:
        pass

    return best_type, best_waves


def analyze_structure_phase1_only(df):
    if df.empty:
        return [], pd.DataFrame()

    df_proc = df.reset_index()

    if "Date" not in df_proc.columns and "index" in df_proc.columns:
        df_proc["Date"] = df_proc["index"]

    rename_map = {"open": "Open", "high": "High", "low": "Low", "close": "Close"}
    df_proc = df_proc.rename(columns=rename_map)

    lows, highs = df_proc["Low"].values, df_proc["High"].values
    idx_abs_low, idx_abs_high = np.argmin(lows), np.argmax(highs)

    if idx_abs_low > idx_abs_high:
        idx_abs_high = len(df_proc) - 1

    wa = WaveAnalyzer(df=df_proc, verbose=False)
    gens = {
        "impulse": WaveOptionsGenerator5(up_to=3),
        "correction": WaveOptionsGenerator3(up_to=3)
    }
    rules = {
        "impulse": Impulse("impulse"),
        "correction": Correction("correction")
    }

    final_wave_objects = []
    curr_idx = idx_abs_low

    while curr_idx < idx_abs_high - 5:
        p_type, waves = find_best_fit(wa, curr_idx, idx_abs_high, gens, rules)
        if waves:
            final_wave_objects.append((p_type, waves))
            curr_idx = waves[-1].idx_end
            if curr_idx >= idx_abs_high:
                break
        else:
            curr_idx += 2

    df_raw_phase2 = df_proc.iloc[idx_abs_high:]
    json_waves = []

    for p_type, waves in final_wave_objects:
        labels = ["1", "2", "3", "4", "5"] if p_type == "Impulse" else ["A", "B", "C"]
        for i, w in enumerate(waves):
            is_up = "Up" in w.__class__.__name__
            end_price = w.high if is_up else w.low
            end_idx = w.idx_end
            end_date = df_proc.iloc[end_idx]["Date"]
            lbl = labels[i] if i < len(labels) else "?"
            json_waves.append({
                "lbl": lbl,
                "p": {
                    "price": float(end_price),
                    "date": str(end_date),
                    "type": "high" if (i % 2 == 0 and p_type == "Impulse") else "low"
                }
            })

    return json_waves, df_raw_phase2


# ==========================================================
# --- CORE BACKEND FUNCTION (CALL THIS FROM SERVER.PY) ---
# ==========================================================
def run_analysis_backend(symbol="BTCUSDT", interval="15m", action="analyze", market_type="crypto"):
    """
    Main entry point for API calls. Returns a DICT (not JSON string).
    """
    symbol = normalize_symbol(symbol)

    # 1. Initialize Keys
    if not load_api_key():
        if not hasattr(config, "API_KEY_POOL") and not hasattr(config, "PAID_API_KEY"):
            print("[WARN] No API keys found, AI might fail.")

    # --- ACTION: SCAN ---
    if action == "scan":
        mode = symbol if symbol in ["scalp", "swing"] else "scalp"

        if market_type == "forex":
            try:
                from .ai_engine import scan_forex_market
                scan_result = scan_forex_market(mode=mode)
            except Exception:
                scan_result = {
                    "candidates": [],
                    "logs": ["Forex Scan Not implemented in modular refactor yet"]
                }
        else:
            scan_result = scan_market(mode=mode)

        final_output = {
            "candidates": scan_result.get("candidates", []),
            "logs": scan_result.get("logs", []),
            "ai_analysis": []
        }

        if final_output["candidates"]:
            try:
                ai_picks_str = analyze_scanner_candidates(final_output["candidates"])
                final_output["ai_analysis"] = json.loads(ai_picks_str)
            except Exception:
                final_output["ai_analysis"] = []

        return final_output

    # --- ACTION: HISTORY ---
    elif action == "history":
        df = get_data(symbol, interval=interval, period="200d", market_type=market_type)
        if not df.empty and "Date" in df.columns:
            df.set_index("Date", inplace=True)
        df = df.tail(1000)

        ohlc_data = []
        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index)

        for date, row in df.iterrows():
            ohlc_data.append({
                "time": int(date.timestamp()),
                "open": float(row["Open"]),
                "high": float(row["High"]),
                "low": float(row["Low"]),
                "close": float(row["Close"])
            })

        return {"ohlc_data": ohlc_data}

    # --- ACTION: STATUS ---
    elif action == "status":
        locked_scenario, lock_time = get_firestore_lock(symbol, interval)
        if not locked_scenario:
            return {
                "ai_prediction": {
                    "trade_status_message": "NO ACTIVE TRADE",
                    "macro_analysis": {"trend": "Unknown"},
                    "micro_analysis": {"wave_personality": "Unknown"},
                    "trade_scenarios": []
                }
            }

        df_micro = get_data(symbol, interval=interval, period="2mo", market_type=market_type)
        if not df_micro.empty and "Date" in df_micro.columns:
            df_micro.set_index("Date", inplace=True)

        if not isinstance(df_micro.index, pd.DatetimeIndex):
            df_micro.index = pd.to_datetime(df_micro.index)

        if df_micro.index.tz is None and hasattr(lock_time, "tzinfo") and lock_time.tzinfo:
            lock_time = lock_time.replace(tzinfo=None)

        df_since_lock = df_micro[df_micro.index >= lock_time]
        if df_since_lock.empty:
            df_since_lock = df_micro.tail(1)

        status, advice = check_trade_status_historical(locked_scenario, df_since_lock)

        if status not in ["WON", "LOST"] and "MISSED" not in status:
            advice = generate_status_update(locked_scenario, df_since_lock)

        if status in ["WON", "LOST"]:
            delete_firestore_lock(symbol, interval)
            status_msg = f"TRADE CLOSED ({status})"
        else:
            status_msg = status

        return {
            "ai_prediction": {
                "trade_status_message": status_msg,
                "action_advice": advice,
                "macro_analysis": {"trend": "LOCKED (Monitoring)"},
                "micro_analysis": {"wave_personality": "Monitoring Phase"},
                "trade_scenarios": [locked_scenario]
            }
        }

    # --- ACTION: ANALYZE (DEFAULT) ---
    else:
        df_macro = get_data(symbol, interval="1d", period="2y", market_type=market_type)
        if not df_macro.empty and "Date" in df_macro.columns:
            df_macro.set_index("Date", inplace=True)

        df_swing = get_data(symbol, interval="4h", period="6mo", market_type=market_type)
        if not df_swing.empty and "Date" in df_swing.columns:
            df_swing.set_index("Date", inplace=True)

        df_micro = get_data(symbol, interval=interval, period="2mo", market_type=market_type)
        if not df_micro.empty and "Date" in df_micro.columns:
            df_micro.set_index("Date", inplace=True)

        macro_waves, _ = analyze_structure_phase1_only(df_macro)
        swing_waves, _ = analyze_structure_phase1_only(df_swing)
        micro_waves, raw_micro_tail = analyze_structure_phase1_only(df_micro)
        market_context_text = build_market_context_text(df_micro, micro_waves)

        print("\n===== MARKET CONTEXT SENT TO AI =====")
        print(market_context_text[:4000])
        print("===== END MARKET CONTEXT =====\n")

        locked_scenario, lock_time = get_firestore_lock(symbol, interval)
        status_message = "LIMIT ORDER | Fresh Setup"
        generated_advice = None

        if locked_scenario and lock_time:
            if not isinstance(df_micro.index, pd.DatetimeIndex):
                df_micro.index = pd.to_datetime(df_micro.index)

            if df_micro.index.tz is None and hasattr(lock_time, "tzinfo") and lock_time.tzinfo:
                lock_time = lock_time.replace(tzinfo=None)

            df_since_lock = df_micro[df_micro.index >= lock_time]

            status, advice = check_trade_status_historical(locked_scenario, df_since_lock)
            status_message = status
            generated_advice = advice

            if status in ["WON", "LOST"]:
                delete_firestore_lock(symbol, interval)
                locked_scenario = None
                status_message = f"TRADE CLOSED ({status})"
            else:
                locked_scenario["generated_advice"] = advice

        elif locked_scenario and not lock_time:
            delete_firestore_lock(symbol, interval)
            locked_scenario = None

        candles_for_ai = raw_micro_tail if len(raw_micro_tail) > 5 else df_micro.tail(20)
        market_bias = get_market_bias()
        cross_tf_context = get_cross_timeframe_context(symbol, interval)

        ai_response_str = generate_mtf_analysis(
            symbol,
            macro_waves,
            swing_waves,
            micro_waves,
            candles_for_ai,
            df_macro,
            interval,
            "Pro",
            locked_scenario,
            market_bias,
            market_type,
            cross_tf_context,
            market_context_text
        )

        try:
            ai_data = json.loads(ai_response_str)
            ai_data["trade_status_message"] = status_message

            if "action_advice" in ai_data and generated_advice == "CHECK_AI":
                generated_advice = ai_data["action_advice"]
            elif generated_advice and "action_advice" in ai_data:
                generated_advice = ai_data["action_advice"]

            if locked_scenario:
                locked_scenario["generated_advice"] = generated_advice
                ai_data["trade_scenarios"] = [locked_scenario, new_alt]
            else:
                if "trade_scenarios" in ai_data and len(ai_data["trade_scenarios"]) > 0:
                    primary_setup = ai_data["trade_scenarios"][0]
                    if "trade_type" in primary_setup and primary_setup["trade_type"] not in ["WAIT", "NEUTRAL"]:
                        primary_setup = enforce_max_rr(primary_setup, max_r=5.0)
                        save_firestore_lock(symbol, interval, primary_setup)

        except Exception as e:
            ai_data = {"error": "AI Parsing Error", "raw": str(ai_response_str)}
            print(f"[ERROR] AI processing failed: {e}")

        ohlc_data = []
        chart_df = df_macro
        if not isinstance(chart_df.index, pd.DatetimeIndex):
            chart_df.index = pd.to_datetime(chart_df.index)

        for date, row in chart_df.iterrows():
            ohlc_data.append({
                "time": int(date.timestamp()),
                "open": float(row["Open"]),
                "high": float(row["High"]),
                "low": float(row["Low"]),
                "close": float(row["Close"])
            })

        return {
            "meta": {"symbol": symbol, "timeframe": "Daily (Macro)"},
            "waves": {"macro": macro_waves, "swing": swing_waves, "micro": micro_waves},
            "ohlc_data": ohlc_data,
            "market_context": market_context_text,
            "ai_prediction": ai_data
        }


# --- CLI ENTRY POINT (For Testing) ---
if __name__ == "__main__":
    arg1 = sys.argv[1] if len(sys.argv) > 1 else "BTCUSDT"
    arg2 = sys.argv[2] if len(sys.argv) > 2 else "15m"
    action = sys.argv[3] if len(sys.argv) > 3 else "analyze"
    market_type = sys.argv[4] if len(sys.argv) > 4 else "crypto"

    result = run_analysis_backend(arg1, arg2, action, market_type)
    print(json.dumps(result, indent=4))