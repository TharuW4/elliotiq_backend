import math
import pandas as pd
import numpy as np


# Added 0.236 for shallow pullbacks in strong trends.
FIB_RETRACEMENTS = [0.236, 0.382, 0.5, 0.618, 0.786]
FIB_EXTENSIONS = [1.0, 1.272, 1.618, 2.0]


def _safe_float(value):
    """
    Safely convert values into float.
    Handles None, NaN, Infinity, numpy numbers, and comma-formatted strings.
    """
    try:
        if value is None:
            return None

        if isinstance(value, (int, float, np.integer, np.floating)):
            value = float(value)
            if math.isnan(value) or math.isinf(value):
                return None
            return value

        cleaned = str(value).replace(",", "").strip()
        if cleaned == "":
            return None

        value = float(cleaned)
        if math.isnan(value) or math.isinf(value):
            return None

        return value
    except Exception:
        return None


def _format_price(value):
    value = _safe_float(value)
    if value is None:
        return "N/A"

    if abs(value) >= 100:
        return f"{value:.2f}"
    if abs(value) >= 1:
        return f"{value:.4f}"
    return f"{value:.8f}"


def calculate_atr(df, period=14):
    """
    Calculate ATR from OHLC dataframe.
    Expected columns: High, Low, Close
    """
    try:
        if df is None or df.empty:
            return None

        required = {"High", "Low", "Close"}
        if not required.issubset(set(df.columns)):
            return None

        data = df.copy()

        high_low = data["High"] - data["Low"]
        high_close = (data["High"] - data["Close"].shift()).abs()
        low_close = (data["Low"] - data["Close"].shift()).abs()

        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr = true_range.ewm(alpha=1 / period, adjust=False).mean()

        return _safe_float(atr.iloc[-1])
    except Exception:
        return None


def dynamic_sr_tolerance(current_price=None, atr=None):
    """
    Dynamic support/resistance grouping tolerance.

    For BTC/ETH/SOL/low-price coins, fixed tolerance can be too strict or too loose.
    This uses ATR% when available, otherwise falls back to 0.3%.
    """
    try:
        current_price = _safe_float(current_price)
        atr = _safe_float(atr)

        if current_price is None or current_price <= 0:
            return 0.003

        if atr is None or atr <= 0:
            return 0.003

        atr_pct = atr / current_price

        # Keep tolerance reasonable:
        # minimum 0.2%, maximum 0.8%
        return min(max(atr_pct * 0.75, 0.002), 0.008)
    except Exception:
        return 0.003


def detect_swing_levels(df, lookback=120, window=3):
    """
    Basic swing high / swing low detection.
    window=3 reduces noise on 15m crypto compared to window=2.
    """
    result = {
        "swing_highs": [],
        "swing_lows": [],
        "recent_swing_high": None,
        "recent_swing_low": None,
    }

    try:
        if df is None or df.empty:
            return result

        required = {"High", "Low", "Close"}
        if not required.issubset(set(df.columns)):
            return result

        data = df.tail(lookback).copy()

        if len(data) < window * 2 + 5:
            return result

        highs = []
        lows = []

        for i in range(window, len(data) - window):
            curr_high = data["High"].iloc[i]
            curr_low = data["Low"].iloc[i]

            left_highs = data["High"].iloc[i - window:i]
            right_highs = data["High"].iloc[i + 1:i + 1 + window]

            left_lows = data["Low"].iloc[i - window:i]
            right_lows = data["Low"].iloc[i + 1:i + 1 + window]

            if curr_high > left_highs.max() and curr_high > right_highs.max():
                highs.append(_safe_float(curr_high))

            if curr_low < left_lows.min() and curr_low < right_lows.min():
                lows.append(_safe_float(curr_low))

        highs = [x for x in highs if x is not None]
        lows = [x for x in lows if x is not None]

        result["swing_highs"] = highs[-12:]
        result["swing_lows"] = lows[-12:]
        result["recent_swing_high"] = highs[-1] if highs else None
        result["recent_swing_low"] = lows[-1] if lows else None

        return result
    except Exception:
        return result


def group_levels(levels, tolerance_pct=0.003):
    """
    Group nearby support/resistance levels.
    tolerance_pct is dynamic when called from get_nearest_sr().
    """
    try:
        clean = []
        for x in levels:
            val = _safe_float(x)
            if val is not None:
                clean.append(val)

        clean = sorted(clean)

        if not clean:
            return []

        zones = []
        current_group = [clean[0]]

        for price in clean[1:]:
            base = sum(current_group) / len(current_group)

            if base != 0 and abs(price - base) / abs(base) <= tolerance_pct:
                current_group.append(price)
            else:
                zones.append({
                    "price": sum(current_group) / len(current_group),
                    "strength": len(current_group),
                    "min": min(current_group),
                    "max": max(current_group),
                })
                current_group = [price]

        zones.append({
            "price": sum(current_group) / len(current_group),
            "strength": len(current_group),
            "min": min(current_group),
            "max": max(current_group),
        })

        zones.sort(key=lambda z: z["strength"], reverse=True)
        return zones
    except Exception:
        return []


def _filter_far_zones(zones, current_price, atr=None, max_pct=0.03, max_atr_mult=5):
    """
    Filter major S/R zones that are too far from current price.
    Keeps context practical for intraday 15m analysis.

    Rule:
    - keep if within 3% OR within 5 ATR
    """
    try:
        current_price = _safe_float(current_price)
        atr = _safe_float(atr)

        if current_price is None or current_price <= 0:
            return zones or []

        filtered = []
        for z in zones or []:
            price = _safe_float(z.get("price"))
            if price is None:
                continue

            dist = abs(price - current_price)
            pct_ok = dist / current_price <= max_pct
            atr_ok = atr is not None and atr > 0 and dist <= atr * max_atr_mult

            if pct_ok or atr_ok:
                filtered.append(z)

        return filtered
    except Exception:
        return zones or []


def get_nearest_sr(df, lookback=120):
    """
    Find nearest support and resistance around current price.
    Uses dynamic tolerance based on ATR/current price.
    """
    context = {
        "current_price": None,
        "nearest_support": None,
        "nearest_resistance": None,
        "major_support": None,
        "major_resistance": None,
        "recent_swing_high": None,
        "recent_swing_low": None,
        "tolerance_pct": None,
    }

    try:
        if df is None or df.empty:
            return context

        data = df.copy()
        current_price = _safe_float(data["Close"].iloc[-1])
        atr = calculate_atr(data, period=14)
        tolerance_pct = dynamic_sr_tolerance(current_price, atr)

        context["current_price"] = current_price
        context["tolerance_pct"] = tolerance_pct

        swings = detect_swing_levels(data, lookback=lookback, window=3)
        highs = swings.get("swing_highs", [])
        lows = swings.get("swing_lows", [])

        context["recent_swing_high"] = swings.get("recent_swing_high")
        context["recent_swing_low"] = swings.get("recent_swing_low")

        resistance_zones = group_levels(highs, tolerance_pct=tolerance_pct)
        support_zones = group_levels(lows, tolerance_pct=tolerance_pct)

        supports_below = [
            z for z in support_zones
            if current_price is not None and _safe_float(z.get("price")) is not None and z["price"] < current_price
        ]

        resistances_above = [
            z for z in resistance_zones
            if current_price is not None and _safe_float(z.get("price")) is not None and z["price"] > current_price
        ]

        supports_below.sort(key=lambda z: abs(current_price - z["price"]))
        resistances_above.sort(key=lambda z: abs(current_price - z["price"]))

        context["nearest_support"] = supports_below[0] if supports_below else None
        context["nearest_resistance"] = resistances_above[0] if resistances_above else None

        # Far-away major levels can mislead AI, so filter them.

        support_zones = _filter_far_zones(support_zones, current_price, atr=atr)
        resistance_zones = _filter_far_zones(resistance_zones, current_price, atr=atr)

        major_support_candidates = [
            z for z in support_zones
            if current_price is not None and _safe_float(z.get("price")) is not None and z["price"] < current_price
        ]

        major_resistance_candidates = [
            z for z in resistance_zones
            if current_price is not None and _safe_float(z.get("price")) is not None and z["price"] > current_price
        ]

        major_support_candidates.sort(key=lambda z: z["strength"], reverse=True)
        major_resistance_candidates.sort(key=lambda z: z["strength"], reverse=True)

        context["major_support"] = major_support_candidates[0] if major_support_candidates else None
        context["major_resistance"] = major_resistance_candidates[0] if major_resistance_candidates else None

        return context
    except Exception:
        return context

def get_major_structure_context(df, lookback=300, window=5):
    """
    Detect larger structure levels from a wider candle window.
    Useful for finding impulse peaks / major support / major resistance
    that may be missed by short-term 120-candle S/R logic.
    """
    context = {
        "major_swing_high": None,
        "major_swing_low": None,
        "major_resistance": None,
        "major_support": None,
        "major_range_high": None,
        "major_range_low": None,
        "lookback": lookback,
    }

    try:
        if df is None or df.empty:
            return context

        required = {"High", "Low", "Close"}
        if not required.issubset(set(df.columns)):
            return context

        data = df.tail(lookback).copy()
        if data.empty:
            return context

        current_price = _safe_float(data["Close"].iloc[-1])
        atr = calculate_atr(data, period=14)
        tolerance_pct = dynamic_sr_tolerance(current_price, atr)

        swings = detect_swing_levels(data, lookback=lookback, window=window)

        highs = swings.get("swing_highs", [])
        lows = swings.get("swing_lows", [])

        clean_highs = [_safe_float(x) for x in highs if _safe_float(x) is not None]
        clean_lows = [_safe_float(x) for x in lows if _safe_float(x) is not None]

        if clean_highs:
            context["major_swing_high"] = max(clean_highs)
            resistance_zones = group_levels(clean_highs, tolerance_pct=tolerance_pct)

            # For major resistance, highest significant zone is more useful than nearest only.
            if resistance_zones:
                resistance_zones.sort(key=lambda z: z["price"], reverse=True)
                context["major_resistance"] = resistance_zones[0]

        if clean_lows:
            context["major_swing_low"] = min(clean_lows)
            support_zones = group_levels(clean_lows, tolerance_pct=tolerance_pct)

            # For major support, lowest significant zone is useful.
            if support_zones:
                support_zones.sort(key=lambda z: z["price"])
                context["major_support"] = support_zones[0]

        context["major_range_high"] = _safe_float(data["High"].max())
        context["major_range_low"] = _safe_float(data["Low"].min())

        return context

    except Exception:
        return context


def extract_wave_prices(waves):
    """
    Extract price values from existing micro_waves format:
    {"lbl": "...", "p": {"price": ..., "date": ..., "type": "..."}}
    """
    prices = []

    try:
        if not waves:
            return prices

        for w in waves:
            p = w.get("p", {}) if isinstance(w, dict) else {}
            price = _safe_float(p.get("price"))

            if price is not None:
                prices.append(price)

        return prices
    except Exception:
        return prices


def calculate_fib_context_from_waves(waves):
    """
    Build simple Fibonacci context from latest detected micro swing.
    This is supporting context only, not a standalone Elliott target engine.
    """
    context = {
        "last_move_start": None,
        "last_move_end": None,
        "direction": "Unknown",
        "retracements": {},
        "extensions": {},
        "shallow_pullback_zone": None,
        "pullback_zone": None,
        "deep_pullback": None,
    }

    try:
        prices = extract_wave_prices(waves)

        if len(prices) < 2:
            return context

        start = prices[-2]
        end = prices[-1]
        move = end - start

        if abs(move) <= 0:
            return context

        direction = "Bullish latest swing" if move > 0 else "Bearish latest swing"

        context["last_move_start"] = start
        context["last_move_end"] = end
        context["direction"] = direction

        retracements = {}
        extensions = {}

        for fib in FIB_RETRACEMENTS:
            if move > 0:
                level = end - (abs(move) * fib)
            else:
                level = end + (abs(move) * fib)
            retracements[str(fib)] = level

        for fib in FIB_EXTENSIONS:
            if move > 0:
                level = end + (abs(move) * fib)
            else:
                level = end - (abs(move) * fib)
            extensions[str(fib)] = level

        context["retracements"] = retracements
        context["extensions"] = extensions

        # Strong-trend shallow pullback zone: 0.236 - 0.382
        r236 = retracements.get("0.236")
        r382 = retracements.get("0.382")

        if r236 is not None and r382 is not None:
            context["shallow_pullback_zone"] = {
                "min": min(r236, r382),
                "max": max(r236, r382),
                "label": "0.236 - 0.382"
            }

        # Normal pullback zone: 0.5 - 0.618
        r50 = retracements.get("0.5")
        r618 = retracements.get("0.618")

        if r50 is not None and r618 is not None:
            context["pullback_zone"] = {
                "min": min(r50, r618),
                "max": max(r50, r618),
                "label": "0.5 - 0.618"
            }

        # Deep pullback: 0.786
        r786 = retracements.get("0.786")

        if r786 is not None:
            context["deep_pullback"] = {
                "price": r786,
                "label": "0.786"
            }

        return context
    except Exception:
        return context


def calculate_fib_context_from_visible_swings(df, lookback=120, window=3):
    """
    Build Fibonacci context from recent visible swing high/low in the chart.
    This is useful when Elliott-detected latest swing is not the same as the visible current trading swing.
    """
    context = {
        "swing_start": None,
        "swing_end": None,
        "direction": "Unknown",
        "retracements": {},
        "extensions": {},
        "shallow_pullback_zone": None,
        "pullback_zone": None,
        "deep_pullback": None,
    }

    try:
        if df is None or df.empty:
            return context

        required = {"High", "Low", "Close"}
        if not required.issubset(set(df.columns)):
            return context

        swings = detect_swing_levels(df, lookback=lookback, window=window)

        swing_points = []

        # Collect recent swing highs
        for price in swings.get("swing_highs", []):
            price = _safe_float(price)
            if price is not None:
                swing_points.append({"price": price, "type": "high"})

        # Collect recent swing lows
        for price in swings.get("swing_lows", []):
            price = _safe_float(price)
            if price is not None:
                swing_points.append({"price": price, "type": "low"})

        if len(swing_points) < 2:
            return context

        # Since detect_swing_levels returns recent values without dates,
        # use the last visible high/low pair by price relationship.
        recent_high = _safe_float(swings.get("recent_swing_high"))
        recent_low = _safe_float(swings.get("recent_swing_low"))
        current_price = _safe_float(df["Close"].iloc[-1])

        if recent_high is None or recent_low is None or current_price is None:
            return context

        # Decide likely active visible swing:
        # If current price is closer to low after a recent high, assume bearish pullback from high to low.
        # If current price is closer to high after a recent low, assume bullish swing from low to high.
        dist_to_high = abs(current_price - recent_high)
        dist_to_low = abs(current_price - recent_low)

        if dist_to_high < dist_to_low:
            # Price near high: likely bullish swing low -> high
            start = recent_low
            end = recent_high
            direction = "Bullish visible swing"
        else:
            # Price near low: likely bearish swing high -> low OR bullish pullback area.
            # For pullback analysis after an impulse, low -> high is usually more useful if high > low.
            start = recent_low
            end = recent_high
            direction = "Bullish visible swing"

        if start is None or end is None or start == end:
            return context

        move = end - start
        if abs(move) <= 0:
            return context

        context["swing_start"] = start
        context["swing_end"] = end
        context["direction"] = direction

        retracements = {}
        extensions = {}

        for fib in FIB_RETRACEMENTS:
            if move > 0:
                level = end - (abs(move) * fib)
            else:
                level = end + (abs(move) * fib)
            retracements[str(fib)] = level

        for fib in FIB_EXTENSIONS:
            if move > 0:
                level = end + (abs(move) * fib)
            else:
                level = end - (abs(move) * fib)
            extensions[str(fib)] = level

        context["retracements"] = retracements
        context["extensions"] = extensions

        r236 = retracements.get("0.236")
        r382 = retracements.get("0.382")
        if r236 is not None and r382 is not None:
            context["shallow_pullback_zone"] = {
                "min": min(r236, r382),
                "max": max(r236, r382),
                "label": "0.236 - 0.382"
            }

        r50 = retracements.get("0.5")
        r618 = retracements.get("0.618")
        if r50 is not None and r618 is not None:
            context["pullback_zone"] = {
                "min": min(r50, r618),
                "max": max(r50, r618),
                "label": "0.5 - 0.618"
            }

        r786 = retracements.get("0.786")
        if r786 is not None:
            context["deep_pullback"] = {
                "price": r786,
                "label": "0.786"
            }

        return context

    except Exception:
        return context


def calculate_volume_context(df, lookback=30):
    """
    Simple volume state.
    Current/latest candle is excluded from average calculation,
    so latest volume is compared against previous average.
    """
    try:
        if df is None or df.empty or "Volume" not in df.columns:
            return {
                "available": False,
                "state": "Volume data unavailable"
            }

        data = df.tail(lookback + 1).copy()

        if len(data) < 6:
            return {
                "available": False,
                "state": "Insufficient volume data"
            }

        last_vol = _safe_float(data["Volume"].iloc[-1])
        prev_avg_vol = _safe_float(data["Volume"].iloc[:-1].mean())

        if last_vol is None or prev_avg_vol is None or prev_avg_vol == 0:
            return {
                "available": False,
                "state": "Invalid volume data"
            }

        ratio = last_vol / prev_avg_vol

        if ratio >= 1.8:
            state = "Very high volume"
        elif ratio >= 1.3:
            state = "High volume"
        elif ratio >= 1.1:
            state = "Above average volume"
        elif ratio <= 0.6:
            state = "Low volume"
        else:
            state = "Normal volume"

        # Lightweight health hint only. AI should not treat this as a hard rule.
        try:
            recent_closes = data["Close"].iloc[-6:]
            recent_vols = data["Volume"].iloc[-6:]

            price_change = _safe_float(recent_closes.iloc[-1] - recent_closes.iloc[0])

            vol_first_avg = _safe_float(recent_vols.iloc[:3].mean())
            vol_second_avg = _safe_float(recent_vols.iloc[3:].mean())

            volume_change = None
            if vol_first_avg is not None and vol_second_avg is not None:
                volume_change = vol_second_avg - vol_first_avg

            if price_change is not None and volume_change is not None:
                if price_change > 0 and volume_change > 0:
                    health = "Price rising with increasing volume"
                elif price_change > 0 and volume_change < 0:
                    health = "Price rising but volume weakening"
                elif price_change < 0 and volume_change > 0:
                    health = "Price falling with increasing volume"
                elif price_change < 0 and volume_change < 0:
                    health = "Price falling but selling volume weakening"
                else:
                    health = "Volume trend neutral"
            else:
                health = "Volume health unavailable"
        except Exception:
            health = "Volume health unavailable"

        return {
            "available": True,
            "last_volume": last_vol,
            "average_volume": prev_avg_vol,
            "ratio": ratio,
            "state": state,
            "health": health
        }
    except Exception:
        return {
            "available": False,
            "state": "Volume context error"
        }


def build_market_context_text(df_micro, micro_waves):
    """
    Final text block to inject into AI prompt.
    This gives AI better context without forcing final trade decisions.
    """
    try:
        if df_micro is None or df_micro.empty:
            return "Market context unavailable."

        current_price = _safe_float(df_micro["Close"].iloc[-1])
        atr = calculate_atr(df_micro, period=14)
        atr_pct = None
        if atr is not None and current_price is not None and current_price != 0:
            atr_pct = atr / current_price * 100

        sr = get_nearest_sr(df_micro, lookback=120)
        major_structure = get_major_structure_context(df_micro, lookback=300, window=5)
        fib = calculate_fib_context_from_waves(micro_waves)
        fib_status = "VALID"
        fib_warning = ""

        fib_start = _safe_float(fib.get("last_move_start"))
        fib_end = _safe_float(fib.get("last_move_end"))

        if current_price is not None and fib_start is not None and fib_end is not None:
            dist_start_pct = abs(fib_start - current_price) / current_price if current_price != 0 else 0
            dist_end_pct = abs(fib_end - current_price) / current_price if current_price != 0 else 0

            if dist_start_pct > 0.30 and dist_end_pct > 0.30:
                fib_status = "STALE"
                fib_warning = "Elliott Fib Context is STALE / far from current price. Do not use for entry."

        visible_fib = calculate_fib_context_from_visible_swings(df_micro, lookback=120, window=3)
        volume = calculate_volume_context(df_micro, lookback=30)

        nearest_support = sr.get("nearest_support")
        nearest_resistance = sr.get("nearest_resistance")
        major_support = sr.get("major_support")
        major_resistance = sr.get("major_resistance")
        major_swing_high = major_structure.get("major_swing_high")
        major_swing_low = major_structure.get("major_swing_low")
        long_range_high = major_structure.get("major_range_high")
        long_range_low = major_structure.get("major_range_low")
        long_major_support = major_structure.get("major_support")
        long_major_resistance = major_structure.get("major_resistance")

        fib_shallow = fib.get("shallow_pullback_zone")
        fib_pullback = fib.get("pullback_zone")
        fib_deep = fib.get("deep_pullback")
        visible_fib_shallow = visible_fib.get("shallow_pullback_zone")
        visible_fib_pullback = visible_fib.get("pullback_zone")
        visible_fib_deep = visible_fib.get("deep_pullback")

        lines = []

        lines.append("--- MARKET STRUCTURE CONTEXT ---")
        lines.append(f"Current Price: {_format_price(current_price)}")

        if atr is not None:
            if atr_pct is not None:
                lines.append(f"ATR(14): {_format_price(atr)} ({atr_pct:.2f}% of price)")
            else:
                lines.append(f"ATR(14): {_format_price(atr)}")
        else:
            lines.append("ATR(14): N/A")

        if sr.get("tolerance_pct") is not None:
            lines.append(f"Dynamic S/R Grouping Tolerance: {sr.get('tolerance_pct') * 100:.2f}%")

        lines.append(f"Recent Swing High: {_format_price(sr.get('recent_swing_high'))}")
        lines.append(f"Recent Swing Low: {_format_price(sr.get('recent_swing_low'))}")

        if nearest_support:
            lines.append(
                f"Nearest Support: {_format_price(nearest_support.get('price'))} "
                f"(strength {nearest_support.get('strength')})"
            )
        else:
            lines.append("Nearest Support: N/A")

        if nearest_resistance:
            lines.append(
                f"Nearest Resistance: {_format_price(nearest_resistance.get('price'))} "
                f"(strength {nearest_resistance.get('strength')})"
            )
        else:
            lines.append("Nearest Resistance: N/A")

        if major_support:
            lines.append(
                f"Major Support Zone: {_format_price(major_support.get('min'))} - {_format_price(major_support.get('max'))} "
                f"(strength {major_support.get('strength')})"
            )
        else:
            lines.append("Major Support Zone: N/A")

        if major_resistance:
            lines.append(
                f"Major Resistance Zone: {_format_price(major_resistance.get('min'))} - {_format_price(major_resistance.get('max'))} "
                f"(strength {major_resistance.get('strength')})"
            )
        else:
            lines.append("Major Resistance Zone: N/A")


        lines.append("")
        lines.append("--- LARGER STRUCTURE CONTEXT ---")
        lines.append(f"Long Lookback Range High: {_format_price(long_range_high)}")
        lines.append(f"Long Lookback Range Low: {_format_price(long_range_low)}")
        lines.append(f"Major Swing High / Possible Impulse Peak: {_format_price(major_swing_high)}")
        lines.append(f"Major Swing Low / Possible Correction Base: {_format_price(major_swing_low)}")

        if long_major_support:
            lines.append(
                f"Long Lookback Major Support Zone: "
                f"{_format_price(long_major_support.get('min'))} - {_format_price(long_major_support.get('max'))} "
                f"(strength {long_major_support.get('strength')})"
            )
        else:
            lines.append("Long Lookback Major Support Zone: N/A")

        if long_major_resistance:
            lines.append(
                f"Long Lookback Major Resistance Zone: "
                f"{_format_price(long_major_resistance.get('min'))} - {_format_price(long_major_resistance.get('max'))} "
                f"(strength {long_major_resistance.get('strength')})"
            )
        else:
            lines.append("Long Lookback Major Resistance Zone: N/A")

        lines.append("")
        lines.append("--- FIBONACCI CONTEXT FROM LATEST MICRO SWING ---")
        lines.append(f"Elliott Fib Context Status: {fib_status}")
        if fib_warning:
            lines.append(f"Warning: {fib_warning}")
        lines.append(f"Last Swing Direction: {fib.get('direction', 'Unknown')}")
        lines.append(f"Last Swing Start: {_format_price(fib.get('last_move_start'))}")
        lines.append(f"Last Swing End: {_format_price(fib.get('last_move_end'))}")

        if fib_shallow:
            lines.append(
                f"Shallow Pullback Zone ({fib_shallow.get('label')}): "
                f"{_format_price(fib_shallow.get('min'))} - {_format_price(fib_shallow.get('max'))}"
            )
        else:
            lines.append("Shallow Pullback Zone: N/A")

        if fib_pullback:
            lines.append(
                f"Normal Pullback Zone ({fib_pullback.get('label')}): "
                f"{_format_price(fib_pullback.get('min'))} - {_format_price(fib_pullback.get('max'))}"
            )
        else:
            lines.append("Normal Pullback Zone: N/A")

        if fib_deep:
            lines.append(f"Deep Pullback ({fib_deep.get('label')}): {_format_price(fib_deep.get('price'))}")
        else:
            lines.append("Deep Pullback: N/A")

        extensions = fib.get("extensions", {})

        if extensions:
            ext_text = []
            for k in ["1.0", "1.272", "1.618", "2.0"]:
                if k in extensions:
                    ext_text.append(f"{k}: {_format_price(extensions[k])}")

            lines.append("Continuation Extension Levels From Last Swing End: " + " | ".join(ext_text))
        else:
            lines.append("Continuation Extension Levels From Last Swing End: N/A")


        lines.append("")
        lines.append("--- FIBONACCI CONTEXT FROM RECENT VISIBLE SWING HIGH/LOW ---")
        lines.append(f"Visible Swing Direction: {visible_fib.get('direction', 'Unknown')}")
        lines.append(f"Visible Swing Start: {_format_price(visible_fib.get('swing_start'))}")
        lines.append(f"Visible Swing End: {_format_price(visible_fib.get('swing_end'))}")

        if visible_fib_shallow:
            lines.append(
                f"Visible Shallow Pullback Zone ({visible_fib_shallow.get('label')}): "
                f"{_format_price(visible_fib_shallow.get('min'))} - {_format_price(visible_fib_shallow.get('max'))}"
            )
        else:
            lines.append("Visible Shallow Pullback Zone: N/A")

        if visible_fib_pullback:
            lines.append(
                f"Visible Normal Pullback Zone ({visible_fib_pullback.get('label')}): "
                f"{_format_price(visible_fib_pullback.get('min'))} - {_format_price(visible_fib_pullback.get('max'))}"
            )
        else:
            lines.append("Visible Normal Pullback Zone: N/A")

        if visible_fib_deep:
            lines.append(f"Visible Deep Pullback ({visible_fib_deep.get('label')}): {_format_price(visible_fib_deep.get('price'))}")
        else:
            lines.append("Visible Deep Pullback: N/A")

        visible_extensions = visible_fib.get("extensions", {})
        if visible_extensions:
            visible_ext_text = []
            for k in ["1.0", "1.272", "1.618", "2.0"]:
                if k in visible_extensions:
                    visible_ext_text.append(f"{k}: {_format_price(visible_extensions[k])}")

            lines.append("Visible Continuation Extension Levels: " + " | ".join(visible_ext_text))
        else:
            lines.append("Visible Continuation Extension Levels: N/A")

        lines.append("")
        lines.append("--- VOLUME CONTEXT ---")
        lines.append(f"Volume State: {volume.get('state', 'Unknown')}")

        if volume.get("available"):
            lines.append(f"Latest Volume vs Previous Average: {volume.get('ratio'):.2f}x")
            lines.append(f"Volume Health: {volume.get('health', 'Unknown')}")

        lines.append("")
        lines.append("IMPORTANT USAGE INSTRUCTION:")
        lines.append("- Elliott Wave structure remains the PRIMARY model. This context can only confirm, weaken, or reject Elliott-based scenarios.")
        lines.append("- Do not create a trade only from this market context.")
        lines.append("- Use these levels as supporting context, not forced trade signals.")
        lines.append("- Use Larger Structure Context to identify major impulse peaks, major resistance, and larger correction zones.")
        lines.append("- Entry should be near support/resistance or one of the printed Fibonacci pullback zones.")
        lines.append("- Do not claim Fibonacci confluence unless entry is close to a printed Fibonacci level/zone.")
        lines.append("- If Elliott-based Fibonacci and visible-swing Fibonacci conflict, prioritize the one that matches current price action and explain it.")
        lines.append("- Stop loss should be beyond nearest valid structural invalidation, not exactly on the level.")
        lines.append("- ATR can be used as a buffer/check for stop loss placement, often around 1.5x to 2x ATR when appropriate.")
        lines.append("- Use ATR to judge whether the stop loss is too wide or too tight; do not set SL mechanically from ATR alone.")
        lines.append("- TP2 should respect nearby resistance/support or continuation extension levels.")
        lines.append("- If current price is already close to TP1, return WAIT / NO CHASE.")
        lines.append("- Latest candle may be incomplete depending on data source; treat current price/volume context carefully.")
        lines.append("- If Elliott Fib Context Status is STALE, ignore it for entry and prioritize visible swing / larger structure context.")

        return "\n".join(lines)

    except Exception as e:
        return f"Market context error: {str(e)}"