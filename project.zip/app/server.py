import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from . import main  # ඔයාගේ main.py එක මෙතනට import කරනවා

app = Flask(__name__)
CORS(app) # ඕනෑම තැනක ඉඳන් access කරන්න දෙනවා

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        data = request.json
        
        # App එකෙන් එවන Data ටික ගන්න
        symbol = data.get('symbol', 'BTCUSDT')
        interval = data.get('interval', '15m')
        action = data.get('action', 'analyze') # analyze, status, scan, history
        market_type = data.get('market_type', 'crypto')
        
        # main.py එකේ අපි අලුතින් හදපු backend function එක call කරනවා
        result = main.run_analysis_backend(symbol, interval, action, market_type)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e), "status": "failed"}), 500

if __name__ == '__main__':
    # Cloud Run එකේදී PORT environment variable එකෙන් port එක ගන්නවා
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)