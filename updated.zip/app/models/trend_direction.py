import math
import re
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

# Global Constants
BULLISH = "BULLISH"
BEARISH = "BEARISH"
NEUTRAL = "NEUTRAL"
MIXED = "MIXED"
UNKNOWN = "UNKNOWN"

# ==========================================================
# LEAD AI v2: TREND DIRECTION GATEKEEPER
# ==========================================================

def _safe_float(value: Any) -> Optional[float]:
    try:
        if value is None: return None
        if isinstance(value, (int, float, np.integer, np.floating)):
            val = float(value)
            return None if math.isnan(val) or math.isinf(val) else val
        text = str(value).replace(",", "").strip()
        match = re.search(r"-?\d+(?:\.\d+)?", text)
        return float(match.group(0)) if match else None
    except Exception: return None

def _format_price(value: Any) -> str:
    val = _safe_float(value)
    if val is None: return "N/A"
    if abs(val) >= 1000: return f"{val:.2f}"
    if abs(val) >= 10: return f"{val:.3f}"
    return f"{val:.6f}"

def _prepare_df(df: Optional[pd.DataFrame]) -> pd.DataFrame:
    if df is None or df.empty: return pd.DataFrame()
    data = df.copy()
    rename_map = {"open": "Open", "high": "High", "low": "Low", "close": "Close", "volume": "Volume"}
    data = data.rename(columns=rename_map)
    data.columns = [c.capitalize() for c in data.columns]
    return data

def _detect_swing_points(df: pd.DataFrame, lookback: int = 180, window: int = 3) -> List[Dict[str, Any]]:
    points = []
    try:
        data = df.tail(lookback)
        highs, lows = data["High"].values, data["Low"].values
        idxs = list(data.index)
        for i in range(window, len(data) - window):
            if highs[i] > np.nanmax(highs[i-window:i]) and highs[i] > np.nanmax(highs[i+1:i+1+window]):
                points.append({"type": "high", "price": float(highs[i]), "position": i})
            if lows[i] < np.nanmin(lows[i-window:i]) and lows[i] < np.nanmin(lows[i+1:i+1+window]):
                points.append({"type": "low", "price": float(lows[i]), "position": i})
        return points
    except Exception: return points

def _market_structure_bias(df: Optional[pd.DataFrame], timeframe_name: str) -> Dict[str, Any]:
    res = {"bias": UNKNOWN, "last_high": None, "last_low": None}
    data = _prepare_df(df)
    if data.empty: return res
    swings = _detect_swing_points(data)
    h = [p["price"] for p in swings if p["type"] == "high"]
    l = [p["price"] for p in swings if p["type"] == "low"]
    if len(h) < 2 or len(l) < 2: return res
    
    res["last_high"], res["last_low"] = h[-1], l[-1]
    hh, hl = h[-1] > h[-2], l[-1] > l[-2]
    lh, ll = h[-1] < h[-2], l[-1] < l[-2]

    if hh and hl: res["bias"] = BULLISH
    elif lh and ll: res["bias"] = BEARISH
    else: res["bias"] = MIXED
    return res

# --- MAIN ENGINE (UNIVERSAL VERSION) ---

def build_dominant_trend_context(
    df_macro: Optional[pd.DataFrame] = None,
    df_swing: Optional[pd.DataFrame] = None,
    df_confirm_1h: Optional[pd.DataFrame] = None, # (Variable නම වෙනස් නොකරමු, main.py එකට error එන නිසා)
    df_micro: Optional[pd.DataFrame] = None,
    user_tf: str = "15m",
    **kwargs # Other wave data
) -> str:
    try:
        df_sw = _prepare_df(df_swing)
        df_conf = _prepare_df(df_confirm_1h)
        df_mic = _prepare_df(df_micro)
        
        curr_price = _safe_float(df_mic["Close"].iloc[-1]) if not df_mic.empty else 0
        
        # 1. EMA 200 Hard Filter (Universal Confirm TF)
        confirm_closes = df_conf["Close"].dropna()
        ema200_confirm = confirm_closes.ewm(span=200, adjust=False).mean().iloc[-1]
        ema_bias = BULLISH if curr_price > ema200_confirm else BEARISH

        # 2. Market Structure (Heavy Weights)
        struct_swing = _market_structure_bias(df_sw, "Swing TF")
        struct_confirm = _market_structure_bias(df_conf, "Confirm TF")

        # 3. Decision Logic (RELAXED FOR MORE SIGNALS)
        preferred_side = "WAIT"
        is_broken = False
        
        # Bullish condition: As long as EMA is Bullish and at least ONE structure (Swing or Confirm) is Bullish
        if ema_bias == BULLISH and (struct_confirm["bias"] == BULLISH or struct_swing["bias"] == BULLISH):
            preferred_side = "LONG"
            # Anti-top check: If price broke below last Confirm TF low, block Long
            if struct_confirm["last_low"] and curr_price < struct_confirm["last_low"]:
                is_broken, preferred_side = True, "WAIT"

        # Bearish condition: As long as EMA is Bearish and at least ONE structure (Swing or Confirm) is Bearish
        elif ema_bias == BEARISH and (struct_confirm["bias"] == BEARISH or struct_swing["bias"] == BEARISH):
            preferred_side = "SHORT"
            # Anti-bottom check: If price broke above last Confirm TF high, block Short
            if struct_confirm["last_high"] and curr_price > struct_confirm["last_high"]:
                is_broken, preferred_side = True, "WAIT"

        # 4. Universal Text Builder
        lines = [
            "--- DOMINANT TREND CONTEXT (LEAD AI v2 - UNIVERSAL) ---",
            f"Dominant Direction: {struct_confirm['bias']}",
            f"Preferred Trade Side: {preferred_side}",
            f"EMA 200 Filter (Confirm TF): {ema_bias}",
            f"Structure Broken (CHoCH): {'YES' if is_broken else 'NO'}",
            "",
            "CRITICAL DIRECTION RULES:",
            f"- NO LONGs below EMA200 ({_format_price(ema200_confirm)})",
            f"- NO SHORTs above Confirm TF Swing High ({_format_price(struct_confirm['last_high'])})",
            "- If CHoCH is YES, AI MUST return WAIT.",
            f"- Swing TF Structure is currently {struct_swing['bias']}."
        ]
        return "\n".join(lines)

    except Exception as e:
        return f"Trend Logic Error: {str(e)}"